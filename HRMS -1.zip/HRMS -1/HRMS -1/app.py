from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.secret_key = '49494asdklfjasdklflaksd'

# SQLAlchemy configurations
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:root@localhost/new_data'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)


# Define the User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)
    role = db.Column(db.String(50), nullable=False)


@app.route('/')
def home():
    return render_template('home.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        role = request.form['role']
        email = request.form['email']
        password = request.form['password']

        user = User.query.filter_by(email=email, password=password, role=role).first()

        if user:
            return redirect(url_for('home'))  # Redirect to the dashboard or home page
        else:
            flash('Login Failed. Check your role, email, and password.')
            return redirect(url_for('login'))  # Redirect to login page
    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        role = request.form['role']

        if password != confirm_password:
            flash('Passwords do not match!')
            return redirect(url_for('register'))

        new_user = User(name=name, email=email, password=password, role=role)
        db.session.add(new_user)
        db.session.commit()

        flash('Registration successful! Please log in.')
        return redirect(url_for('login'))  # Redirect to login page

    return render_template('register.html')


@app.route('/job_desk')
def job_desk():
    return render_template('job_desk.html')


@app.route('/Employee')
def Employee():
    return render_template('employee.html')


@app.route('/Leave')
def Leave():
    return render_template('leave.html')


@app.route('/dashboard')
def dashboard():
    return "Welcome to the Admin Dashboard!"
    '''if 'logged_in' in session and session['role'] == 'App Admin':
        return render_template('dashboard.html')
    return redirect(url_for('login'))'''


if __name__ == '__main__':
    app.run(debug=True)
