from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

# Define trigger points and corresponding options
trigger_options = {
    'hello': ['Job Search', 'Resume Tips', 'Other'],
    'job search': ['IT Job', 'Pharma Job', 'Manufacture Job'],
    'resume tips': ['Available Soon'],
    'other': ['Sorry for Inconvenience'],
}

# Initialize conversation state
conversation_state = {
    'current_trigger': None
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json['message']
    response, options = generate_response(user_message)
    return jsonify({'response': response, 'options': options})

def generate_response(user_message):
    global conversation_state

    user_message = user_message.lower()

    # Check if the user message matches any trigger option
    if user_message in ['hi', 'hello']:
        conversation_state['current_trigger'] = 'hello'
        return "Hello! How can I help you?", trigger_options['hello']

    # Handle the user message based on the current conversation state
    current_trigger = conversation_state.get('current_trigger')
    if current_trigger:
        if current_trigger == 'hello':
            if user_message in ['job search', 'resume tips', 'other']:
                conversation_state['current_trigger'] = user_message
                return f"You selected {user_message}. Here are your options:", trigger_options[user_message]
            else:
                return "I'm sorry, I didn't understand that. Please choose one of the options.", trigger_options['hello']
        elif current_trigger == 'job search':
            if user_message in ['it job', 'pharma job', 'manufacture job']:
                return "Available Soon.", []
            else:
                return "I'm sorry, I didn't understand that. Please choose one of the options.", trigger_options['job search']
        elif current_trigger == 'resume tips':
            return "Resume tips are currently available soon.", []
        elif current_trigger == 'other':
            return "Sorry for the inconvenience.", []

    # Default response if no conditions are met
    return "I'm sorry, I didn't understand that.", []

if __name__ == '__main__':
    app.run(debug=True)
