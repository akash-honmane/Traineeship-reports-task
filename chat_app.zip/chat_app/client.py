import socket
import threading


def main():
    c_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    host = '127.0.0.1'
    port = 5959
    c_socket.connect((host, port))

    while True:
        message = input("Enter your message: ")
        c_socket.sendall(message.encode('utf-8'))
        data = c_socket.recv(1024)
        response = data.decode('utf-8')
        print(f"SERVER RESPONSE:\n {response}")

if __name__ == "__main__":
    main()