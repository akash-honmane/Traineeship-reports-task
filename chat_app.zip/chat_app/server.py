import socket
import threading

def server1(c_socket):
    while True:
        data = c_socket.recv(1024)
        if not data:
            break
        msg = data.decode('utf-8')
        print(f" Your Message is Received: {msg}")
        response = "Server Received Your Message: " + msg
        c_socket.sendall(response.encode('utf-8'))
    c_socket.close()

def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    host = '127.0.0.1'
    port = 5959
    server_socket.bind((host, port))
    server_socket.listen(5)
    print(f"Server listening on {host}:{port}")

    while True:
        c_socket, client_address = server_socket.accept()
        print(f" Connection Accepted From {client_address}")
        client_handler = threading.Thread(target=server1, args=(c_socket,))
        client_handler.start()

if __name__ == "__main__":
    main()
