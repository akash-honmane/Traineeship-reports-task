# app/routes.py

import json
import hmac
import hashlib
from flask import Blueprint, render_template, url_for, flash, redirect, request, abort
from app import db
from app.models import User, Bill
from flask_login import login_user, current_user, logout_user, login_required
from werkzeug.security import generate_password_hash, check_password_hash
import razorpay
from datetime import datetime
import random

main = Blueprint('main', __name__)

razorpay_client = razorpay.Client(auth=("rzp_test_vFyApXafcsJq65", "7GBdgwYdfR9krDyVCg41Wauw"))

def generate_bill_for_user(user):
    amount = round(random.uniform(100, 500), 2)  # Generate a random amount between 100 and 500
    bill = Bill(amount=amount, user_id=user.id, date=datetime.utcnow(), status='Unpaid')
    db.session.add(bill)
    db.session.commit()
    print(f"Generated bill for user {user.username}: {bill.amount} on {bill.date}")

@main.route('/')
def home():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    return redirect(url_for('main.login'))

@main.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        user = User(username=username, email=email, password=hashed_password)
        db.session.add(user)
        db.session.commit()
        flash('Your account has been created!', 'success')
        return redirect(url_for('main.login'))
    return render_template('register.html')

@main.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password, password):
            login_user(user)
            # Generate a bill if the user doesn't have one
            if not user.bills:
                generate_bill_for_user(user)
            return redirect(url_for('main.dashboard'))
        else:
            flash('Login Unsuccessful. Please check email and password', 'danger')
    return render_template('login.html')

@main.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('main.login'))

@main.route('/dashboard')
@login_required
def dashboard():
    bills = current_user.bills
    print(f"User {current_user.username} has the following bills: {bills}")
    return render_template('dashboard.html', bills=bills)

@main.route('/bill/<int:bill_id>')
@login_required
def bill(bill_id):
    bill = Bill.query.get_or_404(bill_id)
    return render_template('bill.html', bill=bill)

@main.route('/pay/<int:bill_id>', methods=['GET', 'POST'])
@login_required
def pay(bill_id):
    bill = Bill.query.get_or_404(bill_id)
    if request.method == 'POST':
        payment = razorpay_client.order.create({
            "amount": int(bill.amount * 100),  # amount in paise
            "currency": "INR",
            "payment_capture": "1"
        })
        return render_template('pay.html', bill=bill, payment=payment)
    else:
        return render_template('pay.html', bill=bill)

@main.route('/payment_success', methods=['POST'])
def payment_success():
    payload = request.get_data(as_text=True)
    signature = request.headers.get('X-Razorpay-Signature')

    try:
        data = json.loads(payload)
        order_id = data['payload']['payment']['entity']['order_id']
        payment_id = data['payload']['payment']['entity']['id']

        # Verify the payment signature
        generated_signature = hmac.new(
            key=bytes("7GBdgwYdfR9krDyVCg41Wauw", 'utf-8'),
            msg=bytes(order_id + "|" + payment_id, 'utf-8'),
            digestmod=hashlib.sha256
        ).hexdigest()

        if hmac.compare_digest(generated_signature, signature):
            # Payment is successful and verified
            bill = Bill.query.filter_by(order_id=order_id).first()
            if bill:
                bill.status = 'Paid'
                db.session.commit()
                flash('Payment successful!', 'success')
            else:
                flash('Bill not found', 'danger')
        else:
            flash('Payment signature verification failed', 'danger')
    except Exception as e:
        flash('Payment processing error: ' + str(e), 'danger')
        abort(400)

    return redirect(url_for('main.dashboard'))

# Error handling middleware
@main.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500

@main.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404
