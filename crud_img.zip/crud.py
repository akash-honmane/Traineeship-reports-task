import mysql.connector
from PIL import Image
import io

# Establish connection to MySQL database
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="img_db"
)
cursor = conn.cursor()


# Function to insert an image into the database
def insert_image(image_path):
    # Read the image
    with open(image_path, "rb") as file:
        image_data = file.read()

    # Prepare SQL query to insert image into the database
    query = "INSERT INTO images (image_data) VALUES (%s)"

    # Execute the query
    cursor.execute(query, (image_data,))
    conn.commit()


# Function to retrieve an image from the database
def retrieve_image(image_id):
    # Prepare SQL query to retrieve image from the database
    query = "SELECT image_data FROM images WHERE id = %s"

    # Execute the query
    cursor.execute(query, (image_id,))

    # Fetch the result
    image_data = cursor.fetchone()

    if image_data is not None:
        # Convert binary data to image
        image = Image.open(io.BytesIO(image_data[0]))
        image.show()
    else:
        print("Image not found for the given ID.")


# Function to update an image in the database
def update_image(image_id, new_image_path):
    # Read the new image
    with open(new_image_path, "rb") as file:
        new_image_data = file.read()

    # Prepare SQL query to update image in the database
    query = "UPDATE images SET image_data = %s WHERE id = %s"

    # Execute the query
    cursor.execute(query, (new_image_data, image_id))
    conn.commit()


# Function to delete an image from the database
def delete_image(image_id):
    # Prepare SQL query to delete image from the database
    query = "DELETE FROM images WHERE id = %s"

    # Execute the query
    cursor.execute(query, (image_id,))
    conn.commit()


# Example usage
# Inserting an image
insert_image("D:\\Python-Workspace\\NumetryTech\\img\\teamplates\\N1.jpeg")

# Retrieving and displaying an image
retrieve_image(1)

# Updating an image
update_image(1,"D:\\Python-Workspace\\NumetryTech\\img\\teamplates\\N2.jpeg")

# Deleting an image
delete_image(1)

# Close the database connection
conn.close()
