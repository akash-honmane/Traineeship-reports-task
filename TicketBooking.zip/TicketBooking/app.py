from flask import Flask, jsonify, request, render_template
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config[
    'SQLALCHEMY_DATABASE_URI'] = 'mysql://root:root@localhost/ticketdb'  # Replace with your MySQL connection string
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


# Define database models
class Train(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    number = db.Column(db.String(50), nullable=False)


class Bus(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    number = db.Column(db.String(50), nullable=False)


class Taxi(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    number = db.Column(db.String(50), nullable=False)


class Ticket(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    passenger_name = db.Column(db.String(255), nullable=False)
    transport_type = db.Column(db.String(50), nullable=False)
    transport_id = db.Column(db.Integer, nullable=False)


# Create database tables
with app.app_context():
    db.create_all()


# Routes for managing data
@app.route('/trains', methods=['GET', 'POST'])
def manage_trains():
    if request.method == 'GET':
        trains = Train.query.all()
        return jsonify([{'id': train.id, 'name': train.name, 'number': train.number} for train in trains])
    elif request.method == 'POST':
        data = request.json
        train = Train(name=data['name'], number=data['number'])
        db.session.add(train)
        db.session.commit()
        return jsonify({'message': 'Train data added successfully'})


@app.route('/buses', methods=['GET', 'POST'])
def manage_buses():
    if request.method == 'GET':
        buses = Bus.query.all()
        return jsonify([{'id': bus.id, 'name': bus.name, 'number': bus.number} for bus in buses])
    elif request.method == 'POST':
        data = request.json
        bus = Bus(name=data['name'], number=data['number'])
        db.session.add(bus)
        db.session.commit()
        return jsonify({'message': 'Bus data added successfully'})


@app.route('/taxis', methods=['GET', 'POST'])
def manage_taxis():
    if request.method == 'GET':
        taxis = Taxi.query.all()
        return jsonify([{'id': taxi.id, 'name': taxi.name, 'number': taxi.number} for taxi in taxis])
    elif request.method == 'POST':
        data = request.json
        taxi = Taxi(name=data['name'], number=data['number'])
        db.session.add(taxi)
        db.session.commit()
        return jsonify({'message': 'Taxi data added successfully'})


@app.route('/book-ticket', methods=['POST'])
def book_ticket():
    data = request.json
    ticket = Ticket(passenger_name=data['passenger_name'], transport_type=data['transport_type'],
                    transport_id=data['transport_id'])
    db.session.add(ticket)
    db.session.commit()
    return jsonify({'message': 'Ticket booked successfully'})
    # if not ticket:
    #     return jsonify({'message': 'Data not found'})


@app.route('/tickets', methods=['GET'])
def get_tickets():
    tickets = Ticket.query.all()
    return jsonify([{'id': ticket.id, 'passenger_name': ticket.passenger_name, 'transport_type': ticket.transport_type,
                     'transport_id': ticket.transport_id} for ticket in tickets])


@app.route('/')
def index():
    return render_template('index.html')


if __name__ == '__main__':
    app.run(debug=True)
