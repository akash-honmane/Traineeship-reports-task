from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'my_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:root@localhost/notes_passwords'
db = SQLAlchemy(app)

class Note(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255))
    content = db.Column(db.Text)

class Password(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    note_id = db.Column(db.Integer, db.ForeignKey('note.id'))
    website = db.Column(db.String(255))
    username = db.Column(db.String(255))
    password_hash = db.Column(db.String(255))


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/notes')
def notes():
    all_notes = Note.query.all()
    return render_template('notes.html', notes=all_notes)

@app.route('/notes/add', methods=['GET', 'POST'])
def add_note():
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        new_note = Note(title=title, content=content)
        db.session.add(new_note)
        db.session.commit()
        return redirect(url_for('notes'))
    return render_template('add_note.html')

# Note: Implement password setting mechanism for notes
@app.route('/notes/set_password/<int:id>', methods=['GET', 'POST'])
def set_note_password(id):
    note = Note.query.get_or_404(id)

    if request.method == 'POST':
        password = request.form.get('password')
        password_hash = generate_password_hash(password)
        new_password = Password(note_id=id, password_hash=password_hash)
        db.session.add(new_password)
        db.session.commit()
        flash('Password set for the note successfully!', 'success')
        return redirect(url_for('notes'))

    return render_template('set_note_password.html', note=note)


@app.route('/notes/edit/<int:id>', methods=['GET', 'POST'])
def edit_note(id):
    note = Note.query.get_or_404(id)

    if request.method == 'POST':
        password = request.form.get('password')
        note_password = Password.query.filter_by(note_id=id).first()
        if note_password and check_password_hash(note_password.password_hash, password):
            note.title = request.form['title']
            note.content = request.form['content']
            db.session.commit()
            flash('Note edited successfully!', 'success')
            return redirect(url_for('notes'))
        else:
            flash('Incorrect password!', 'error')

    return render_template('edit_note.html', note=note)


@app.route('/notes/delete/<int:id>', methods=['GET', 'POST'])
def delete_note(id):
    note = Note.query.get_or_404(id)
    note_password = None  # Default value if password is not found

    if request.method == 'POST':
        password = request.form.get('password')
        note_password = Password.query.filter_by(note_id=id).first()
        if note_password and check_password_hash(note_password.password_hash, password):
            db.session.delete(note)
            db.session.commit()
            flash('Note deleted successfully!', 'success')
            return redirect(url_for('notes'))
        else:
            flash('Incorrect password! Note was not deleted.', 'error')

    return render_template('delete_note.html', note=note, password=note_password)

@app.route('/passwords')
def passwords():
    all_passwords = Password.query.all()
    return render_template('passwords.html', passwords=all_passwords)

@app.route('/passwords/add', methods=['GET', 'POST'])
def add_password():
    if request.method == 'POST':
        website = request.form['website']
        username = request.form['username']
        password = request.form['password']
        # Hash the password before storing
        password_hash = generate_password_hash(password)
        new_password = Password(website=website, username=username, password_hash=password_hash)
        db.session.add(new_password)
        db.session.commit()
        return redirect(url_for('passwords'))
    return render_template('add_password.html')

# Implement edit and delete operations for passwords as needed
@app.route('/passwords/edit/<int:id>', methods=['GET', 'POST'])
def edit_password(id):
    password = Password.query.get_or_404(id)
    if request.method == 'POST':
        # Update password data and commit changes
        return redirect(url_for('passwords'))
    return render_template('edit_password.html', password=password)

@app.route('/passwords/delete/<int:id>')
def delete_password(id):
    password = Password.query.get_or_404(id)
    db.session.delete(password)
    db.session.commit()
    flash('Password deleted successfully!', 'success')
    return redirect(url_for('passwords'))


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        app.run(debug=True)
