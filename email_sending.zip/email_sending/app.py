from flask import Flask, render_template, request, redirect, url_for
from flask_mail import Mail, Message
import smtplib

app = Flask(__name__)

# Configuration for Flask-Mail
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USE_SSL'] = False
app.config['MAIL_USERNAME'] = 'py.my.testing@gmail.com'
app.config['MAIL_PASSWORD'] = 'liud rnbd sqhm shtu'
app.config['MAIL_DEFAULT_SENDER'] = ('Akash', 'py.my.testing@gmail.com')

mail = Mail(app)

@app.route('/')
def index():
    return render_template('form.html')

@app.route('/submit-form', methods=['POST'])
def submit_form():
    username = request.form['username']
    email = request.form['email']
    password = request.form['password']  # Note: In a real application, handle passwords securely.

    # Send email
    try:
        subject = 'Registration Confirmation'
        html_body = render_template('email.html', username=username)
        msg = Message(subject, recipients=[email], html=html_body)
        mail.send(msg)
        return render_template('email.html')
    except Exception as e:
        return str(e)

if __name__ == '__main__':
    app.run(debug=True)
