from flask import Flask, request, jsonify, render_template
from flask_sqlalchemy import SQLAlchemy
# from app import db

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:root@localhost/voter_system'
db = SQLAlchemy(app)

class Voter(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    age = db.Column(db.Integer, nullable=False)

    def __init__(self, name, age):
        self.name = name
        self.age = age

    def validate_age(self):
        try:
            age = int(self.age)
        except ValueError:
            return "Age must be a valid integer."

        if age < 18:
            return "Voter must be 18 years or older."
        elif age > 75:
            return "Voter must be 75 years or younger."
        else:
            return None

with app.app_context():
    # Create all tables
    db.create_all()

# Homepage route - Renders index.html
@app.route('/')
def index():
    return render_template('index.html')

# Route to display form for creating a new voter - Renders create_voter.html
@app.route('/create_voter_form')
def create_voter_form():
    return render_template('create_voter.html')

# Create a new voter
@app.route('/voter', methods=['POST'])
def create_voter():
    name = request.form.get('name')
    age = request.form.get('age')
    new_voter = Voter(name=name, age=age)
    error = new_voter.validate_age()
    if error:
        return jsonify({'error': error}), 400
    db.session.add(new_voter)
    db.session.commit()
    return jsonify({'message': 'Voter created successfully'}), 201

# Retrieve all voters and display them using voters.html
@app.route('/voters', methods=['GET'])
def get_voters():
    voters = Voter.query.all()
    return render_template('voters.html', voters=voters)

# Update a voter's information
@app.route('/voter/<int:voter_id>', methods=['PUT'])
def update_voter(voter_id):
    voter = Voter.query.get_or_404(voter_id)
    voter.name = request.form.get('name', voter.name)
    voter.age = request.form.get('age', voter.age)
    error = voter.validate_age()
    if error:
        return jsonify({'error': error}), 400
    db.session.commit()
    return jsonify({'message': 'Voter updated successfully'})

# Delete a voter
@app.route('/voter/<int:voter_id>', methods=['DELETE'])
def delete_voter(voter_id):
    voter = Voter.query.get_or_404(voter_id)
    db.session.delete(voter)
    db.session.commit()
    return jsonify({'message': 'Voter deleted successfully'})

if __name__ == '__main__':
    app.run(debug=True)
