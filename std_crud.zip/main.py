import mysql.connector

# Function to create a new student record
def create_student(conn, student_id, name, age, city, pincode):
    cursor = conn.cursor()
    cursor.execute('''INSERT INTO students (student_id, name, age, city, pincode)
                      VALUES (%s, %s, %s, %s, %s)''', (student_id, name, age, city, pincode))
    conn.commit()
    return cursor.lastrowid

# Function to retrieve all student records
def get_all_students(conn):
    cursor = conn.cursor()
    cursor.execute('''SELECT * FROM students''')
    return cursor.fetchall()

# Function to retrieve a specific student record by ID
def get_student_by_id(conn, student_id):
    cursor = conn.cursor()
    cursor.execute('''SELECT * FROM students WHERE student_id = %s''', (student_id,))
    return cursor.fetchone()

# Function to update a student record
def update_student(conn, student_id, name=None, age=None, city=None, pincode=None):
    cursor = conn.cursor()
    update_fields = []

    if name:
        update_fields.append("name = %s")
    if age:
        update_fields.append("age = %s")
    if city:
        update_fields.append("city = %s")
    if pincode:
        update_fields.append("pincode = %s")

    if update_fields:
        update_query = '''UPDATE students SET {} WHERE student_id = %s'''.format(', '.join(update_fields))
        cursor.execute(update_query, (name, age, city, pincode, student_id))
        conn.commit()

# Function to delete a student record
def delete_student(conn, student_id):
    cursor = conn.cursor()
    cursor.execute('''DELETE FROM students WHERE student_id = %s''', (student_id,))
    conn.commit()

# Main function to take user input and demonstrate CRUD operations
def main():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="student_dbb"
    )

    cursor = conn.cursor()

    # Create a table for students if it doesn't exist
    cursor.execute('''CREATE TABLE IF NOT EXISTS students
                      (id INT AUTO_INCREMENT PRIMARY KEY,
                      student_id INT,
                      name VARCHAR(255),
                      age INT,
                      city VARCHAR(255),
                      pincode VARCHAR(10))''')

    print("Enter student details:")
    student_id = int(input("Student ID: "))
    name = input("Name: ")
    age = int(input("Age: "))
    city = input("City: ")
    pincode = input("Pincode: ")

    create_student(conn, student_id, name, age, city, pincode)
    print("Student record created successfully.")

    print("All students:")
    print(get_all_students(conn))

    student_id = int(input("\nEnter the Student ID to update: "))
    name = input("New Name (Press Enter to skip): ")
    age = int(input("New Age (Press Enter to skip): "))
    city = input("New City (Press Enter to skip): ")
    pincode = input("New Pincode (Press Enter to skip): ")

    update_student(conn, student_id, name, age, city, pincode)
    print("Student record updated successfully.")

    print("All students after update:")
    print(get_all_students(conn))

    student_id = int(input("\nEnter the Student ID to delete: "))
    delete_student(conn, student_id)
    print("Student record deleted successfully.")

    print("All students after delete:")
    print(get_all_students(conn))

    conn.close()

if __name__ == "__main__":
    main()
