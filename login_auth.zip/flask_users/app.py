
from flask import Flask, render_template, request, redirect, url_for, session, flash
import mysql.connector
from mysql.connector import Error
from werkzeug.security import generate_password_hash, check_password_hash
from flask import jsonify

app = Flask(__name__)
app.secret_key = 'my_key'

# Function to create database connection
def get_db_connection():
    try:
        conn = mysql.connector.connect(
            host='localhost',
            database='mydb',
            user='root',
            password='root'
        )
        if conn.is_connected():
            return conn
    except Error as e:
        print("Database connection error:", e)
        flash('Database connection error', 'danger')
    return None

# Function to check if user is logged in
def is_logged_in():
    return 'user' in session

# Decorator to protect routes that require authentication
def login_required(f):
    def decorated_function(*args, **kwargs):
        if not is_logged_in():
            flash('Please log in to access this page', 'danger')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

# Route for the home page
@app.route('/')
def index():
    if is_logged_in():
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']

        conn = get_db_connection()
        if conn is None:
            return jsonify({'success': False, 'message': 'Error: Database connection failed'})

        try:
            cursor = conn.cursor()
            hashed_password = generate_password_hash(password)
            cursor.execute('INSERT INTO users (username, password, role) VALUES (%s, %s, %s)',
                           (username, hashed_password, role))
            conn.commit()
            cursor.close()
            conn.close()
            return jsonify({'success': True, 'message': 'User successfully registered'})
        except Error as e:
            print("Error during registration:", e)
            return jsonify({'success': False, 'message': 'Error during registration'})

    return render_template('register.html')


# Route for user login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_db_connection()
        if conn is None:
            return redirect(url_for('login'))

        try:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM users WHERE username = %s', (username,))
            user = cursor.fetchone()
            cursor.close()
            conn.close()

            if user and check_password_hash(user[2], password):
                session['user'] = user[1]
                session['role'] = user[3]
                flash('You are now logged in', 'success')
                return redirect(url_for('dashboard'))
            else:
                flash('Invalid username or password', 'danger')
                return redirect(url_for('login'))
        except Error as e:
            print("Error during login:", e)
            flash('Error during login', 'danger')
            return redirect(url_for('login'))

    return render_template('login.html')

# Route for user logout
@app.route('/logout')
@login_required
def logout():
    session.clear()
    flash('You are now logged out', 'success')
    return redirect(url_for('login'))

# Route for the dashboard
@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html', username=session['user'], role=session['role'])

if __name__ == '__main__':
    app.run(debug=True)


