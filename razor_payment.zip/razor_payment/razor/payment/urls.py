
from django.urls import path
from .views import homepage, success

urlpatterns = [
    path('', homepage, name='homepage'),
    path('success' , success , name='success')
]
