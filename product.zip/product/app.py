from flask import Flask, request, jsonify, send_from_directory, render_template
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename
import os

UPLOAD_FOLDER = r'D:\Python-Workspace\NumetryTech\product\data'  # Folder where uploaded files will be stored
ALLOWED_EXTENSIONS = {'mp4', 'mov', 'avi', 'pdf', 'docx', 'xlsx', 'png', 'jpg', 'jpeg'}

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:root@localhost/productdb'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['ALLOWED_EXTENSIONS'] = ALLOWED_EXTENSIONS
db = SQLAlchemy(app)

# Create upload directories if they don't exist
for folder in ['images', 'videos', 'files']:
    upload_dir = os.path.join(app.config['UPLOAD_FOLDER'], folder)
    if not os.path.exists(upload_dir):
        os.makedirs(upload_dir)

# Product Model
class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    price = db.Column(db.Float, nullable=False)
    description = db.Column(db.Text)
    images = db.Column(db.String(255))
    videos = db.Column(db.String(255))
    files = db.Column(db.String(255))

# Create database tables
with app.app_context():
    db.create_all()

# Check if the uploaded file has a valid extension
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

# Create Product
@app.route('/products', methods=['POST'])
def create_product():
    data = request.form
    new_product = Product(
        name=data['name'],
        price=float(data['price']),
        description=data.get('description', ''),
        images=request.files['images'].filename if 'images' in request.files else '',
        videos=request.files['videos'].filename if 'videos' in request.files else '',
        files=request.files['files'].filename if 'files' in request.files else ''
    )
    db.session.add(new_product)
    db.session.commit()
    # Save uploaded files to the current directory
    if 'images' in request.files:
        filename = secure_filename(request.files['images'].filename)
        request.files['images'].save(os.path.join(app.config['UPLOAD_FOLDER'], 'images', filename))
    if 'videos' in request.files:
        filename = secure_filename(request.files['videos'].filename)
        request.files['videos'].save(os.path.join(app.config['UPLOAD_FOLDER'], 'videos', filename))
    if 'files' in request.files:
        filename = secure_filename(request.files['files'].filename)
        request.files['files'].save(os.path.join(app.config['UPLOAD_FOLDER'], 'files', filename))
    return jsonify({'message': 'Product created successfully'}), 201

# Read Product
@app.route('/products', methods=['GET'])
def get_products():
    products = Product.query.all()
    product_list = [{
        'id': product.id,
        'name': product.name,
        'price': product.price,
        'description': product.description,
        'images': product.images,
        'videos': product.videos,
        'files': product.files
    } for product in products]
    return jsonify(product_list), 200

# Render HTML template
@app.route('/', methods=['GET'])
def render_html():
    return render_template('index.html')

# Download Files
@app.route('/download/images/<path:filename>', methods=['GET'])
def download_image(filename):
    return send_from_directory(os.path.join(app.config['UPLOAD_FOLDER'], 'images'), filename, as_attachment=True)

@app.route('/download/videos/<path:filename>', methods=['GET'])
def download_video(filename):
    return send_from_directory(os.path.join(app.config['UPLOAD_FOLDER'], 'videos'), filename, as_attachment=True)

@app.route('/download/files/<path:filename>', methods=['GET'])
def download_file(filename):
    directory = os.path.join(app.config['UPLOAD_FOLDER'], 'files')
    file_path = os.path.join(directory, filename)

    if os.path.exists(file_path):
        return send_from_directory(directory, filename, as_attachment=True)
    else:
        return jsonify({"error": "File not found"}), 404


@app.route('/list_files')
def list_files():
    directory = os.path.join(app.config['UPLOAD_FOLDER'], 'files')
    files_list = os.listdir(directory)
    return jsonify(files_list)


if __name__ == '__main__':
    app.run(debug=True)