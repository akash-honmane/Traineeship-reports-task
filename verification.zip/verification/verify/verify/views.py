from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.conf import settings
from twilio.rest import Client
from twilio.http.http_client import TwilioHttpClient
import certifi
import requests

def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        phone_number = request.POST['phone_number']

        try:
            if User.objects.filter(username=username).exists():
                error_message = "Username is already taken. Please choose a different one."
                return render(request, 'register.html', {'error_message': error_message})

            user = User.objects.create_user(username=username, password=password)
            user.save()
            login(request, user)

            if not phone_number.startswith('+'):
                error_message = "Phone number must be in international format, starting with '+'."
                return render(request, 'register.html', {'error_message': error_message})

            class CertifiTwilioHttpClient(TwilioHttpClient):
                def __init__(self, *args, **kwargs):
                    super().__init__(*args, **kwargs)
                    self.session.verify = certifi.where()

            client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN,
                            http_client=CertifiTwilioHttpClient())

            try:
                message = client.messages.create(
                    body="Thank you for registering on our platform!",
                    from_=settings.TWILIO_PHONE_NUMBER,
                    to=phone_number
                )
                return redirect('success')
            except Exception as e:
                return render(request, 'register.html', {'error_message': f"Failed to send SMS: {str(e)}"})

        except requests.exceptions.SSLError:
            return render(request, 'register.html', {'error_message': "SSL error occurred. Please try again later."})

        except Exception:
            return render(request, 'register.html',
                          {'error_message': "An error occurred during registration. Please try again."})

    return render(request, 'register.html')


def success(request):
    return render(request, 'success.html')
